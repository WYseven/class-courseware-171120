<template>
  <div>
    我是404页面,你访问的页面被带走了
  </div>
</template>
